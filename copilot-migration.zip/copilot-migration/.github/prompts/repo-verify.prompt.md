---
description: Check a migrated repo matches its ADO source
mode: agent
---

Verify the repo `${input:repo:repo name}` (GitHub repo `${input:ghrepo:GitHub repo name, blank if same}`). Read-only.

1. ADO: list branches and tags and the head SHA of the default branch (ado tools, or `git ls-remote <ado url>`).
2. GitHub: the same for `ADHPlatform/<repo>` (github tools, or `git ls-remote https://cencora.ghe.com/ADHPlatform/<repo>.git`).
3. Compare: branch count, tag count, default branch name, head SHA. Any difference is a failure; list it.
4. Check LFS objects if `.gitattributes` has `filter=lfs`.
5. Append a row to `docs/migration/log.md`: date, repo, "repo imported", pass/fail, counts.
Show me pass or fail with the table.
