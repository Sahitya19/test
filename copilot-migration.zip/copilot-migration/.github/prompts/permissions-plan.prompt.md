---
description: Map ADO groups and branch policies to GitHub teams, rulesets and CODEOWNERS
mode: agent
---

Plan access and branch protection. Follow the instructions file.

Inputs: `security-groups.csv`, `branch-policies.csv`, `environment-checks.csv`, `docs/migration/waves.md`.

1. Map each ADO group to a GitHub team and role: Readers → read, Contributors → write, Build Administrators / release approvers → maintain, Project Administrators → admin (flag if more than 5 people). Prefer one team per app (`<app>-readers`, `-developers`, `-maintainers`). If the group mirrors an Entra group, say so: the team should sync from it.
2. Branch policies → rules: reviewers count, build validation → required status checks (name the future workflow job), comment resolution, merge types, path reviewers → CODEOWNERS lines. Note anything with no GitHub equivalent.
3. Environment checks → GitHub environments: approvers → required reviewers (team, max 6 reviewers per environment), branch control → deployment branch policy `main` only for prod, business hours → wait timer or a check job.
4. Write `docs/security/permissions-plan.md` and `scripts/migration/permissions-<wave>.ps1` (dry run default) with:
   `gh api -X POST /orgs/ADHPlatform/teams -f name=<team> -f privacy=closed`
   `gh api -X PUT /orgs/ADHPlatform/teams/<team>/repos/ADHPlatform/<repo> -f permission=<role>`
   environment creation `gh api -X PUT /repos/ADHPlatform/<repo>/environments/<env> --input <json>`
   and one `CODEOWNERS` file per repo under `docs/security/codeowners/<repo>`.
5. List what needs an org owner (teams, org rulesets) versus what a repo admin can do.
