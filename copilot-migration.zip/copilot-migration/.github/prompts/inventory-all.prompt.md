---
description: Collect and join the full ADO inventory into one report
mode: agent
---

Build the full migration inventory. Follow `.github/copilot-instructions.md`.

## Step 1: Collect (ask before each command, show it first)
Check which of these exist; for each missing one, show me the command and run it when I agree:
1. `gh ado2gh inventory-report --ado-org <org>` run inside `docs/inventory/gei/` (needs `$env:ADO_PAT`).
2. `./scripts/Get-AdoMigrationInventory.ps1 -Organization <org> -Project Platform` → `docs/inventory/raw/`.
3. `./scripts/Get-ServiceConnectionRoles.ps1` (needs `az login`).
4. Actions Importer audit in `docs/inventory/importer-audit/` (locally `gh actions-importer audit azure-devops --output-dir docs/inventory/importer-audit`, or the `actions-importer-audit` workflow if there is no Docker).
5. Artifacts kit output in `docs/artifacts/inventory/raw/` (optional).
If a script reports failed calls, read its `errors.csv` and tell me which PAT scope or permission is missing.

## Step 2: Join per repo
For each ADO repo, collect: size, default branch, last push (GEI), build definitions (yaml/classic, last run), release definitions that use its builds, service connections used (`service-connection-usage.csv` by definition name), variable groups and secure files referenced (search the YAML in the clone folder if I give one; otherwise mark Unknown), environments, branch policies, feeds published or consumed, Terraform modules it contains or consumes.
Flag: repos over 5 GB, files over 100 MB, disabled repos, pipelines not run in 90 days (candidates to drop), service connections not used in 90 days (drop), secrets expiring in the next 90 days.

## Step 3: Write `docs/inventory/<YYYY-MM-DD>-inventory.md`
Sections: Headline (3 bullets) · Totals table (repos, YAML builds, classic builds, releases, service connections by type and scheme, variable groups, secret variables, secure files, environments with approvals, branch policies, agent pools, feeds) · Per-repo table · Drop candidates (unused pipelines, connections, variable groups) · Risks found · Data notes.
Then show me the headline and totals in chat and suggest `/plan-waves`.
