---
description: Group classic releases and builds into shared workflow patterns
mode: agent
---

Find the shared workflows we need. Follow the instructions file.

Inputs: `release-stage-tasks.csv`, `release-definitions.csv`, `build-definitions.csv`, `task-groups.csv`, the Actions Importer audit.

1. Normalise each release stage's task sequence (ignore display-name differences, keep task types and their key inputs like Terraform command or app type).
2. Cluster identical or near-identical sequences. For each cluster: name (for example `deploy-terraform`, `deploy-webapp`, `deploy-function`, `run-sql`), number of releases and stages using it, the inputs that vary (which become `workflow_call` inputs), approvals and gates seen.
3. Same for YAML templates and task groups → reusable workflows and composite actions.
4. From the importer audit, list tasks the importer cannot convert, with counts, and propose one custom transformer or composite action for each one that appears 5 or more times.
5. Write `docs/migration/pipeline-patterns.md`: pattern table, mapping of every release definition to a pattern (or "custom"), and the list of reusable workflows to build in `ADHPlatform/platform-workflows`, ordered by how many pipelines each unlocks.
6. Draft the top 3 reusable workflows in `workflows-draft/` using OIDC `azure/login`, `environment:` per stage, and `runs-on: [self-hosted, aca]`.
