---
description: Convert one ADO pipeline to a GitHub Actions workflow using the shared patterns
mode: agent
---

Convert ADO pipeline `${input:id:build or release definition id}` (type `${input:kind:pipeline or release}`). Follow the instructions file.

1. Show me the dry-run command and run it when I agree: `gh actions-importer dry-run azure-devops ${input:kind} --pipeline-id ${input:id} --output-dir out/dry-run`.
2. Read the generated YAML and the manual-steps notes.
3. Rewrite it to: call the matching reusable workflow from `docs/migration/pipeline-patterns.md` where one exists; use OIDC (`permissions: id-token: write`, `azure/login` with `vars.AZURE_CLIENT_ID` etc.) instead of any service connection; use environment names from `docs/security/permissions-plan.md`; read secrets from Key Vault per `docs/security/library-plan.md`; `runs-on: [self-hosted, aca]`; pin third-party actions to a full commit SHA.
4. Save as `workflows-draft/<repo>/<name>.yml` and list: what changed from the importer output, anything not converted, and the test plan (green run on main, deploy to dev, then each environment with approval).
5. Do not push to the app repo. Tell me the `gh actions-importer migrate ... --target-url https://cencora.ghe.com/ADHPlatform/<repo>` command, or that I can commit the draft in a PR.
