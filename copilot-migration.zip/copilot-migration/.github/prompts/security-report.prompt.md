---
description: Report security setup and open alerts across migrated repos
mode: agent
---

Report security status across `ADHPlatform` and `ADHPlatform-Modules`. Read-only, GitHub tools.

Per repo: secret scanning on, push protection on, Dependabot alerts on, CodeQL configured (and last analysis date), open alerts by severity (code scanning, secret scanning, Dependabot), branch ruleset applied, CODEOWNERS present, environments with required reviewers. Also: who approved prod deployments in the last 7 days.

Write `docs/security/<YYYY-MM-DD>-security.md` with a table per wave and a short "fix first" list (critical alerts, repos missing protection). Show me the fix-first list.
