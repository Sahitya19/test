<#
.SYNOPSIS
  Exports ADO history you may need for audit after ADO is switched off: build runs, classic release
  deployments with approvers, and the organization audit log. Read-only; writes CSV files.

.DESCRIPTION
  Run it near the end of the 90-day read-only period, then copy the folder to a storage account with
  immutability (for example: az storage blob upload-batch -d ado-history -s <OutDir> --account-name <sa>).
  PAT scopes: Build (Read), Release (Read), Audit Log (Read; needs Project Collection Administrator).

.EXAMPLE
  ./scripts/Export-AdoHistory.ps1 -Organization AnalyticsDataHub -Project Platform -Since 2024-01-01
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)] [string]$Organization,
  [Parameter(Mandatory = $true)] [string[]]$Project,
  [datetime]$Since = (Get-Date).AddYears(-2),
  [string]$OutDir = 'docs/inventory/ado-history',
  [switch]$UseAzCli
)
. "$PSScriptRoot/AdoCommon.ps1"
$script:AdoHeaders = Get-AdoHeaders -UseAzCli:$UseAzCli
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$org = $Organization; $api = 'api-version=7.1'
$min = $Since.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')

$runs = @(); $deps = @(); $audit = @()
foreach ($projName in $Project) {
  $p = [uri]::EscapeDataString($projName)
  Write-Host "Builds in $projName since $min"
  foreach ($b in (Invoke-AdoAll "https://dev.azure.com/$org/$p/_apis/build/builds?minTime=$min&queryOrder=finishTimeDescending&`$top=5000&$api")) {
    $runs += [pscustomobject]@{ project = $projName; definition = $b.definition.name; buildId = $b.id; number = $b.buildNumber; result = $b.result; reason = $b.reason; branch = $b.sourceBranch; commit = $b.sourceVersion; requestedFor = $b.requestedFor.displayName; queued = $b.queueTime; finished = $b.finishTime; keepForever = $b.keepForever }
  }
  Write-Host "Release deployments in $projName since $min"
  foreach ($d in (Invoke-AdoAll "https://vsrm.dev.azure.com/$org/$p/_apis/release/deployments?minStartedTime=$min&`$top=100&queryOrder=descending&$api")) {
    $appr = @($d.preDeployApprovals | Where-Object { -not $_.isAutomated })
    $deps += [pscustomobject]@{
      project = $projName; release = $d.releaseDefinition.name; releaseName = $d.release.name; stage = $d.releaseEnvironment.name
      status = $d.deploymentStatus; attempt = $d.attempt; started = $d.startedOn; completed = $d.completedOn; requestedFor = $d.requestedFor.displayName
      approvedBy = (@($appr | ForEach-Object { $_.approvedBy.displayName }) | Where-Object { $_ }) -join ';'
      approvalStatus = (@($appr | ForEach-Object { $_.status }) -join ';')
      artifacts = (@($d.release.artifacts) | ForEach-Object { "$($_.alias)=$($_.definitionReference.version.name)" }) -join ';'
    }
  }
}

Write-Host 'Organization audit log (ADO keeps 90 days)'
$cont = $null
do {
  $u = "https://auditservice.dev.azure.com/$org/_apis/audit/auditlog?startTime=$min&batchSize=1000&api-version=7.1-preview.1"
  if ($cont) { $u += "&continuationToken=$([uri]::EscapeDataString($cont))" }
  $r = Invoke-Ado $u
  if (-not $r) { break }
  foreach ($e in @($r.decoratedAuditLogEntries)) { if ($e) { $audit += [pscustomobject]@{ timestamp = $e.timestamp; actor = $e.actorDisplayName; action = $e.actionId; area = $e.area; category = $e.categoryDisplayName; project = $e.projectName; details = $e.details; ip = $e.ipAddress } } }
  $cont = $r.continuationToken
  if (-not $r.hasMore) { $cont = $null }
} while ($cont)

Save-Csv $runs  $OutDir 'build-runs.csv'
Save-Csv $deps  $OutDir 'release-deployments.csv'
Save-Csv $audit $OutDir 'audit-log.csv'
Save-Csv $script:AdoErrors $OutDir 'errors.csv'
Write-Host "Builds: $($runs.Count)  Deployments: $($deps.Count)  Audit events: $($audit.Count)  Failed calls: $($script:AdoErrors.Count)"
