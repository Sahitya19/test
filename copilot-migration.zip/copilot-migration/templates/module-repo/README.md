# terraform-azurerm-<module>

<One line: what this module creates.>

## Usage

```hcl
module "<name>" {
  source = "git::https://cencora.ghe.com/ADHPlatform-Modules/terraform-azurerm-<module>.git?ref=v1.0.0"
  # inputs
}
```

Always pin an exact tag. Dependabot opens a PR in your repo when a new version is released.

## Versioning

- `fix:` commits release a PATCH (1.0.1), `feat:` a MINOR (1.1.0), `feat!:` or `BREAKING CHANGE:` a MAJOR (2.0.0).
- Merge the release PR that release-please opens to publish. Never create or move `v*` tags by hand.

## Inputs and outputs

<!-- BEGIN_TF_DOCS -->
<!-- terraform-docs fills this in -->
<!-- END_TF_DOCS -->
