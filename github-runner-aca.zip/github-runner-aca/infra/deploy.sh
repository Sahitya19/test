#!/usr/bin/env bash
# One-off manual deploy from a workstation (az CLI logged in).
# After the first deploy, use .github/workflows/build-runner-image.yml for rebuilds.
set -euo pipefail

RG="${RG:?resource group}"
LOCATION="${LOCATION:-eastus2}"
ACR="${ACR:?existing ACR name}"
RUNNER_SCOPE="${RUNNER_SCOPE:-org}"     # org | repo
GITHUB_REPO="${GITHUB_REPO:-}"          # repo name when RUNNER_SCOPE=repo
# Auth: a GitHub App (APP_ID + INSTALLATION_ID + APP_KEY_FILE), or GH_PAT (classic, repo scope, from a repo admin)
APP_ID="${APP_ID:-}"
INSTALLATION_ID="${INSTALLATION_ID:-}"
APP_KEY_FILE="${APP_KEY_FILE:-}"
if [[ -z "$APP_ID" && -z "${GH_PAT:-}" ]]; then echo "Set APP_ID/INSTALLATION_ID/APP_KEY_FILE or GH_PAT" >&2; exit 1; fi
if [[ "$RUNNER_SCOPE" == "repo" && -z "$GITHUB_REPO" ]]; then echo "Set GITHUB_REPO when RUNNER_SCOPE=repo" >&2; exit 1; fi
NAME_PREFIX="${NAME_PREFIX:-adh-ghrunner${GITHUB_REPO:+-$(echo "$GITHUB_REPO" | tr '[:upper:]_' '[:lower:]-' | cut -c1-12)}}"
SUBNET_ID="${SUBNET_ID:-}"   # optional, for private networking

# Latest runner release (runner binaries always come from github.com)
RUNNER_VERSION="${RUNNER_VERSION:-$(curl -fsSL https://api.github.com/repos/actions/runner/releases/latest | jq -r .tag_name | sed 's/^v//')}"
TAG="${RUNNER_VERSION}-$(date +%Y%m%d)"
echo "Building gh-runner:${TAG}"

# ACR Tasks build: no local Docker needed
az acr build -r "$ACR" -t "gh-runner:${TAG}" -t gh-runner:latest \
  --build-arg RUNNER_VERSION="$RUNNER_VERSION" \
  "$(dirname "$0")/.."

az deployment group create -g "$RG" \
  --template-file "$(dirname "$0")/main.bicep" \
  --parameters \
    location="$LOCATION" \
    acrName="$ACR" \
    image="gh-runner:${TAG}" \
    namePrefix="$NAME_PREFIX" \
    runnerScope="$RUNNER_SCOPE" \
    githubRepo="$GITHUB_REPO" \
    githubAppId="$APP_ID" \
    githubAppInstallationId="$INSTALLATION_ID" \
    githubAppPrivateKey="$( [[ -n "$APP_KEY_FILE" ]] && cat "$APP_KEY_FILE" || true )" \
    githubPat="${GH_PAT:-}" \
    infrastructureSubnetId="$SUBNET_ID"
