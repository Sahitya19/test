// Event-driven Container Apps job that runs ephemeral GitHub Actions runners.
// KEDA's github-runner scaler polls the org's queued jobs and starts one
// execution (one container, one job) per queued job that matches `runnerLabels`.

@description('Region for all resources.')
param location string = resourceGroup().location

@description('Short name prefix, e.g. adh-ghrunner.')
param namePrefix string = 'adh-ghrunner'

@description('Existing ACR that holds the runner image (same resource group).')
param acrName string

@description('Image repository:tag in the ACR, e.g. gh-runner:2.330.0-1.')
param image string

@description('Org URL the runner registers to. GHE.com: https://<subdomain>.ghe.com/<org>.')
param githubUrl string = 'https://cencora.ghe.com/ADHPlatform'

@description('REST API base. GHE.com: https://api.<subdomain>.ghe.com. github.com: https://api.github.com.')
param githubApiUrl string = 'https://api.cencora.ghe.com'

@description('GitHub org name.')
param githubOwner string = 'ADHPlatform'

@description('org = one runner pool for the whole org (needs org runner admin). repo = runners for one repo (needs only repo admin).')
@allowed([ 'org', 'repo' ])
param runnerScope string = 'org'

@description('Repo name (not owner/name) when runnerScope is repo.')
param githubRepo string = ''

@description('GitHub App ID used by both KEDA and the runner. Leave empty to use githubPat instead.')
param githubAppId string = ''

@description('GitHub App installation ID on the org.')
param githubAppInstallationId string = ''

@secure()
@description('Fallback when no GitHub App can be installed: classic PAT with repo scope from a user who is admin on githubRepo (repo scope) or org runner admin (org scope).')
param githubPat string = ''

@secure()
@description('GitHub App private key (PEM). Ignored if keyVaultSecretUri is set.')
param githubAppPrivateKey string = ''

@description('Optional Key Vault secret URI holding the PEM. The job identity needs "Key Vault Secrets User" on it.')
param keyVaultSecretUri string = ''

@description('Custom labels, comma separated. Workflows target them with runs-on: [self-hosted, aca].')
param runnerLabels string = 'aca'

@description('Runner group in the org (create it first if not Default).')
param runnerGroup string = 'Default'

@description('Optional: limit KEDA polling to these repos (comma separated). Reduces API calls on big orgs.')
param repos string = ''

@description('Optional subnet (delegated to Microsoft.App/environments, /27 or larger) for private network access.')
param infrastructureSubnetId string = ''

param cpu string = '2.0'
param memory string = '4Gi'
param maxConcurrentRunners int = 10
@description('Max job duration in seconds.')
param replicaTimeout int = 7200

var useApp = !empty(githubAppId)
var useKeyVault = !empty(keyVaultSecretUri)
var appKeySecret = useKeyVault
  ? { name: 'github-app-key', keyVaultUrl: keyVaultSecretUri, identity: uami.id }
  : { name: 'github-app-key', value: githubAppPrivateKey }
var authSecret = useApp ? appKeySecret : { name: 'github-pat', value: githubPat }
var scalerAuth = useApp
  ? [ { secretRef: 'github-app-key', triggerParameter: 'appKey' } ]
  : [ { secretRef: 'github-pat', triggerParameter: 'personalAccessToken' } ]
var scalerAppMeta = useApp ? { applicationID: githubAppId, installationID: githubAppInstallationId } : {}
var scalerRepos = runnerScope == 'repo' ? { repos: githubRepo } : (empty(repos) ? {} : { repos: repos })
var credEnv = useApp
  ? [
      { name: 'GH_APP_ID', value: githubAppId }
      { name: 'GH_APP_INSTALLATION_ID', value: githubAppInstallationId }
      { name: 'GH_APP_PRIVATE_KEY', secretRef: 'github-app-key' }
    ]
  : [ { name: 'GH_PAT', secretRef: 'github-pat' } ]

resource acr 'Microsoft.ContainerRegistry/registries@2023-07-01' existing = {
  name: acrName
}

resource logs 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: '${namePrefix}-logs'
  location: location
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 30
  }
}

resource uami 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: '${namePrefix}-id'
  location: location
}

// AcrPull for the job identity
resource acrPull 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(acr.id, uami.id, 'acrpull')
  scope: acr
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '7f951dda-4ed3-4680-a7ca-43fe172d538d')
    principalId: uami.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

resource env 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: '${namePrefix}-env'
  location: location
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logs.properties.customerId
        sharedKey: logs.listKeys().primarySharedKey
      }
    }
    workloadProfiles: [
      { name: 'Consumption', workloadProfileType: 'Consumption' }
    ]
    vnetConfiguration: empty(infrastructureSubnetId) ? null : {
      infrastructureSubnetId: infrastructureSubnetId
      internal: true
    }
  }
}

resource job 'Microsoft.App/jobs@2024-03-01' = {
  name: '${namePrefix}-job'
  location: location
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: { '${uami.id}': {} }
  }
  dependsOn: [ acrPull ]
  properties: {
    environmentId: env.id
    workloadProfileName: 'Consumption'
    configuration: {
      triggerType: 'Event'
      replicaTimeout: replicaTimeout
      replicaRetryLimit: 0
      secrets: [ authSecret ]
      registries: [
        { server: acr.properties.loginServer, identity: uami.id }
      ]
      eventTriggerConfig: {
        parallelism: 1
        replicaCompletionCount: 1
        scale: {
          minExecutions: 0
          maxExecutions: maxConcurrentRunners
          pollingInterval: 30
          rules: [
            {
              name: 'github-runner'
              type: 'github-runner'
              metadata: union({
                githubAPIURL: githubApiUrl
                owner: githubOwner
                runnerScope: runnerScope
                labels: runnerLabels
                targetWorkflowQueueLength: '1'
              }, scalerAppMeta, scalerRepos)
              auth: scalerAuth
            }
          ]
        }
      }
    }
    template: {
      containers: [
        {
          name: 'runner'
          image: '${acr.properties.loginServer}/${image}'
          resources: { cpu: json(cpu), memory: memory }
          env: concat([
            { name: 'GH_URL', value: githubUrl }
            { name: 'GH_API_URL', value: githubApiUrl }
            { name: 'GH_OWNER', value: githubOwner }
            { name: 'GH_REPO', value: githubRepo }
            { name: 'RUNNER_SCOPE', value: runnerScope }
            { name: 'RUNNER_LABELS', value: runnerLabels }
            { name: 'RUNNER_GROUP', value: runnerGroup }
            // Lets workflows run `az login --identity --client-id $AZURE_CLIENT_ID` if you grant this identity Azure roles.
            { name: 'AZURE_CLIENT_ID', value: uami.properties.clientId }
          ], credEnv)
        }
      ]
    }
  }
}

output jobName string = job.name
output identityClientId string = uami.properties.clientId
output identityPrincipalId string = uami.properties.principalId
