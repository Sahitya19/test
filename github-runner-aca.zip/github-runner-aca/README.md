# GitHub Actions runners on Azure Container Apps

Replaces the ADO self-hosted agent pools with **ephemeral** GitHub runners. Each queued job
gets a fresh container that registers, runs that one job, and is thrown away. Nothing runs
(or costs money) when the queue is empty.

```
GitHub org (cencora.ghe.com/ADHPlatform)
   │  job queued with runs-on: [self-hosted, aca]
   ▼
KEDA github-runner scaler (inside the Container Apps job, polls every 30s)
   │  starts 1 execution per queued job, up to maxConcurrentRunners
   ▼
Container Apps job execution ── entrypoint.sh ── GitHub App token → registration token
   │                                           └─ config.sh --ephemeral → run.sh (one job) → exit
   ▼
Private Azure resources (via VNet-integrated environment, optional)
```

## Files

| File | What it is |
|---|---|
| `Dockerfile` | Ubuntu 24.04 + Actions runner + Azure CLI, PowerShell, GitHub CLI, git, jq, Python |
| `entrypoint.sh` | Gets a token from the GitHub App, registers an ephemeral org runner, runs one job |
| `infra/main.bicep` | Log Analytics, managed identity (AcrPull), Container Apps environment, event-driven job |
| `infra/deploy.sh` | First manual deploy: `az acr build` + Bicep deployment |
| `.github/workflows/build-runner-image.yml` | Rebuilds the image on the 1st and 15th and rolls the job to it |

## One-time setup

1. **Create a GitHub App** in the ADHPlatform org (Settings → Developer settings → GitHub Apps).
   - Org permission **Self-hosted runners: Read & write**.
   - Repository permissions **Actions: Read** and **Metadata: Read** (KEDA reads queued jobs).
   - Install it on the org (all repos, or the repos that will use these runners).
   - Note the **App ID** and **Installation ID**, then generate a **private key** (.pem).
   - A GitHub App is preferred over a PAT: it isn't tied to a person and has higher API limits.
2. **Create a runner group** (Org settings → Actions → Runner groups), e.g. `aca-linux`, and
   restrict which repos can use it. Pass it as `runnerGroup`.
3. **ACR**: use an existing registry, or create one (`az acr create -n <name> -g <rg> --sku Standard`).
4. **Network** (if pipelines reach private endpoints like today's agents do): create a subnet
   of /27 or larger delegated to `Microsoft.App/environments` in a VNet peered to the hub,
   and pass its ID as `SUBNET_ID`. Outbound must reach `*.ghe.com`, `*.actions.githubusercontent.com`,
   `github.com` and `objects.githubusercontent.com` (action downloads), plus your package feeds.
5. **Deploy**:
   ```bash
   RG=rg-adh-runners ACR=adhacr APP_ID=123456 INSTALLATION_ID=7890123 \
   APP_KEY_FILE=./adh-runner.private-key.pem SUBNET_ID=/subscriptions/.../subnets/aca-runners \
   ./infra/deploy.sh
   ```
   For production, put the .pem in Key Vault and pass `keyVaultSecretUri` instead of the key.
6. **Smoke test**: in any repo,
   ```yaml
   on: workflow_dispatch
   jobs:
     hello:
       runs-on: [self-hosted, aca]
       steps:
         - run: echo "hi from $(hostname)"; az version; pwsh -v
   ```
   Within ~30–60s an execution should appear under the job's *Execution history* in the portal.

## Using it in workflows

- Target the runners with `runs-on: [self-hosted, aca]`.
- Azure access: prefer **OIDC** (`azure/login` with a federated credential) per repo/environment,
  as planned for the service connections. The job's managed identity (`AZURE_CLIENT_ID` is set
  in the container) is available for shared, low-privilege needs only.
- Tools not in the image: use `actions/setup-node`, `setup-dotnet`, `setup-java`,
  `hashicorp/setup-terraform`, etc. If every pipeline needs a tool, bake it into the Dockerfile.

## Mapping from ADO agents

| ADO | GitHub on ACA |
|---|---|
| Agent pool | Runner group + label (one Container Apps job per pool type, e.g. `aca`, `aca-large`) |
| Capabilities / demands | Labels (`runnerLabels`) |
| Long-lived VM agents | One container per job, clean every time |
| Agent update / patching | Image rebuild every 2 weeks (scheduled workflow) |
| Pool scaling | KEDA, `maxConcurrentRunners` per job |

To add a bigger size, deploy main.bicep again with a different `namePrefix`, `runnerLabels=aca-large`,
`cpu=4.0`, `memory=8Gi`.

## Limitations to know before migrating pipelines

- **No Docker daemon.** Container Apps doesn't allow privileged containers, so `docker build`,
  `container:` jobs and `services:` don't work. Build images with `az acr build` instead.
- **Max size on Consumption is 4 vCPU / 8 GiB**. Heavier builds need a Dedicated workload profile.
- **Linux only.** Windows agents need another option (e.g. GitHub-hosted Windows or VM scale-set runners).
- **No warm cache between jobs.** Use `actions/cache` for packages.
- **KEDA polls the GitHub API.** On a big org, set `repos` to limit polling, or rely on the
  GitHub App's higher rate limit.
- **Runner version.** GitHub refuses runners that fall too far behind the latest release, so keep the scheduled rebuild on.

## Repo-level runners (when you only have repo admin rights)

Org-level registration needs an org owner (or a custom org role with "Manage organization runners and runner groups"). Until that is granted, register runners to one repo at a time. You need admin on that repo.

1. Create a classic PAT with the `repo` scope (or a GitHub App installed on just that repo with Administration: read and write, Actions: read, Metadata: read).
2. Deploy one job per repo:
   ```bash
   export RG=rg-gh-runners ACR=<acr> RUNNER_SCOPE=repo GITHUB_REPO=Custodian_Infra_KeyVault
   export GH_PAT=<classic PAT>          # or APP_ID / INSTALLATION_ID / APP_KEY_FILE
   ./infra/deploy.sh
   ```
   Each repo gets its own Container Apps environment and job, named `adh-ghrunner-<repo>-*`.
3. Queue a workflow with `runs-on: [self-hosted, aca]` and check repo Settings > Actions > Runners: a runner appears, runs the job, and is removed.
4. When org access arrives, deploy once with `RUNNER_SCOPE=org` and the GitHub App, then delete the per-repo resource groups or jobs.

Runner groups do not exist at repo scope, so `runnerGroup` is ignored there.
