#!/usr/bin/env bash
# Registers an ephemeral runner (org scope, or one repo with RUNNER_SCOPE=repo), runs exactly one job, then exits.
# Auth: GitHub App (recommended) or a PAT, both injected as Container Apps secrets.
set -euo pipefail

: "${GH_URL:?Set GH_URL, e.g. https://cencora.ghe.com/ADHPlatform}"
: "${GH_API_URL:?Set GH_API_URL, e.g. https://api.cencora.ghe.com (GHE.com) or https://api.github.com}"
: "${GH_OWNER:?Set GH_OWNER, the org name, e.g. ADHPlatform}"
RUNNER_LABELS="${RUNNER_LABELS:-aca,linux-aca}"
RUNNER_GROUP="${RUNNER_GROUP:-Default}"
RUNNER_SCOPE="${RUNNER_SCOPE:-org}"   # org | repo (repo needs only repo admin rights)
RUNNER_NAME="${RUNNER_NAME_PREFIX:-aca}-$(hostname | tail -c 20)-$(head -c4 /dev/urandom | od -An -tx1 | tr -d ' \n')"

log() { echo "[entrypoint] $(date -u +%FT%TZ) $*"; }
b64url() { openssl base64 -A | tr '+/' '-_' | tr -d '='; }

api() { # api METHOD PATH TOKEN
  curl -fsSL -X "$1" \
    -H "Authorization: Bearer $3" \
    -H "Accept: application/vnd.github+json" \
    -H "X-GitHub-Api-Version: 2022-11-28" \
    "${GH_API_URL}$2"
}

access_token() {
  if [[ -n "${GH_APP_ID:-}" && -n "${GH_APP_INSTALLATION_ID:-}" && -n "${GH_APP_PRIVATE_KEY:-}" ]]; then
    local now header payload sig jwt
    now=$(date +%s)
    header=$(printf '{"alg":"RS256","typ":"JWT"}' | b64url)
    payload=$(printf '{"iat":%d,"exp":%d,"iss":"%s"}' $((now - 60)) $((now + 540)) "$GH_APP_ID" | b64url)
    sig=$(printf '%s.%s' "$header" "$payload" \
          | openssl dgst -sha256 -sign <(printf '%s\n' "$GH_APP_PRIVATE_KEY") | b64url)
    jwt="${header}.${payload}.${sig}"
    api POST "/app/installations/${GH_APP_INSTALLATION_ID}/access_tokens" "$jwt" | jq -r .token
  elif [[ -n "${GH_PAT:-}" ]]; then
    printf '%s' "$GH_PAT"
  else
    echo "No credentials: set GH_APP_ID + GH_APP_INSTALLATION_ID + GH_APP_PRIVATE_KEY, or GH_PAT" >&2
    exit 1
  fi
}

TOKEN=$(access_token)
if [[ "$RUNNER_SCOPE" == "repo" ]]; then
  : "${GH_REPO:?Set GH_REPO (repo name only) when RUNNER_SCOPE=repo}"
  REG_PATH="/repos/${GH_OWNER}/${GH_REPO}/actions/runners/registration-token"
  CONFIG_URL="${GH_URL%/}/${GH_REPO}"
  GROUP_ARGS=()   # runner groups exist only at org level
else
  REG_PATH="/orgs/${GH_OWNER}/actions/runners/registration-token"
  CONFIG_URL="$GH_URL"
  GROUP_ARGS=(--runnergroup "$RUNNER_GROUP")
fi
REG_TOKEN=$(api POST "$REG_PATH" "$TOKEN" | jq -r .token)

cd "${RUNNER_HOME:-/home/runner}"
log "Configuring ${RUNNER_NAME} for ${CONFIG_URL} (scope: ${RUNNER_SCOPE}, labels: ${RUNNER_LABELS})"
./config.sh \
  --url "$CONFIG_URL" \
  --token "$REG_TOKEN" \
  --name "$RUNNER_NAME" \
  --labels "$RUNNER_LABELS" \
  "${GROUP_ARGS[@]}" \
  --work _work \
  --ephemeral \
  --disableupdate \
  --unattended \
  --replace

log "Starting runner"
# exec replaces this shell, and env -u strips credentials, so job steps can't read
# them from the environment or /proc. The runner deregisters itself after its one job;
# GitHub also removes ephemeral runners that went offline without running a job.
exec env -u GH_PAT -u GH_APP_PRIVATE_KEY -u GH_APP_ID -u GH_APP_INSTALLATION_ID ./run.sh
