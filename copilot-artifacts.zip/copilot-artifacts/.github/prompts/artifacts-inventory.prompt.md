---
description: Inventory Azure Artifacts feeds, packages, consumers and build artifacts, and write the inventory report
mode: agent
---

Build the Azure Artifacts inventory as of today. Follow `.github/copilot-instructions.md`.

## Step 1: Check prerequisites
1. Ask me for the ADO organization name if `.github/copilot-instructions.md` still says "confirm".
2. Ask whether I have set `$env:ADO_PAT` (Packaging Read, Build Read, Project and Team Read) or want to use `az login` (`-UseAzCli`). Do not ask me to paste the token.
3. Ask for the folder where the ADO repos are cloned, for the consumer scan. If none, offer to clone them with `git clone` into `C:\src\ado` using the repo list from the `ado` tools, or to skip the scan and use ADO code search instead.

## Step 2: Collect (read-only)
Show each command before running it in the terminal:

```powershell
./scripts/Get-AdoArtifactsInventory.ps1 -Organization <org> -IncludeMetrics -IncludeBuildArtifacts -BuildsPerProject 100 [-UseAzCli]
./scripts/Find-FeedConsumers.ps1 -RootPath <clone folder>
```

- If the first script reports failed calls, read `errors.csv`, explain the likely cause (missing scope, no access to a project feed) and offer to re-run.
- If the consumer scan was skipped, use the `ado` search tools to search code for `pkgs.dev.azure.com`, `UniversalPackages@`, `NuGetAuthenticate@`, `npmAuthenticate@` and record the results the same way.
- Only run with `-IncludeProvenance` if I ask, or later for module tag backfill; it is slow.

## Step 3: Analyse
From the CSVs in `docs/artifacts/inventory/raw/`:
1. Per feed: scope, protocols, internal vs upstream-cache package counts, versions, upstreams, retention, permissions.
2. Per internal package: versions, latest, first and last publish, downloads and last download (if collected).
3. Join consumers.csv to packages by feed name and package name (case-insensitive). List which repos publish and which consume each feed.
4. Classify each internal package using the categories in the instructions file.
5. Apply the version cut policy from `docs/artifacts/migration-options.md` and count versions to move vs archive.
6. Build artifacts: per pipeline, artifact names, typical size, how many builds are kept forever or retained by a release.

## Step 4: Write the report
Copy `docs/artifacts/inventory-template.md` to `docs/artifacts/inventory/<YYYY-MM-DD>-inventory.md` and fill every section. Keep the table columns as in the template. Leave nothing as a placeholder: write Unknown and explain in Data notes.

## Step 5: Show me
In chat: the headline, the "Internal packages by type" table, and the top 5 questions for the team. Then tell me to run `/artifacts-plan`.
