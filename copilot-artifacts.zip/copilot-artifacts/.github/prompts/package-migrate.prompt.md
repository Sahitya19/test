---
description: Write a dry-run-first script that moves one package (or one feed) from Azure Artifacts to its planned GitHub target, plus the consumer changes
mode: agent
---

Prepare the migration of package `${input:package:package name, or * for the whole feed}` from feed `${input:feed:Azure Artifacts feed name}`. Follow `.github/copilot-instructions.md`.

## Step 1: Look up the plan
Find the package rows in `docs/artifacts/migration-plan.md` and `docs/artifacts/inventory/raw/versions.csv`. Get type, target, new name, and the exact versions to move. If the package is not in the plan, stop and tell me.

## Step 2: Write the script
Create `scripts/migration/<feed>-<package>.ps1` that:
- reads tokens only from `$env:ADO_PAT` and `$env:GH_PACKAGES_PAT` (classic PAT, `write:packages`);
- has `-DryRun` on by default, so it lists each version, the download and the publish command, and does nothing else; a real run needs `-DryRun:$false`;
- skips a version already present in the target (check first) and logs it;
- writes a log CSV of version, downloaded, published, skipped, error.

Use the method for the type:
- **NuGet**: download each `.nupkg` from `https://pkgs.dev.azure.com/<org>/<project>/_apis/packaging/feeds/<feed>/nuget/packages/<name>/versions/<version>/content?api-version=7.1-preview.1` (drop `<project>/` for an org-scoped feed), then `dotnet nuget push <file> --source https://nuget.cencora.ghe.com/ADHPlatform/index.json --api-key $env:GH_PACKAGES_PAT --skip-duplicate`.
- **npm**: `npm pack <name>@<version>` against the ADO registry, unpack, change `name` to `@adhplatform/<name>` and set `publishConfig.registry` to `https://npm.cencora.ghe.com`, repack, `npm publish`. Keep the version unchanged.
- **Universal, target git tag (terraform-module or source-bundle)**: use `-IncludeProvenance` data (or ask me to run it) to find the build and its `sourceVersion` commit for each version, then print `git tag -a v<version> <commit> -m "Migrated from Azure Artifacts <feed>/<package> <version>"` and `git push origin v<version>` for the target repo in `ADHPlatform-Modules`. Mark versions without provenance as approximate and do not tag them until I confirm a commit.
- **Universal, target release asset**: `az artifacts universal download --organization https://dev.azure.com/<org> [--project <p> --scope project] --feed <feed> --name <name> --version <v> --path <dir>`, zip if needed, then `gh release create v<version> <files> --repo ADHPlatform/<repo>` with `GH_HOST=cencora.ghe.com`.
- **Universal, target OCI**: same download, then `oras push containers.cencora.ghe.com/adhplatform/<name>:<version> <files>`.
- **Maven / PyPI**: do not migrate. Explain that the plan keeps these in Azure Artifacts and write only the GitHub Actions OIDC consumption snippet.

## Step 3: Consumer changes
For each repo in consumers.csv that uses this package, show the exact edit as a diff (nuget.config, .npmrc, package.json alias, Terraform `source`, workflow step). Do not apply edits to other repos; I will raise PRs.

## Step 4: Verify
Write a short checklist: versions in target match the plan, a consumer restore or `terraform init` works from GitHub, ADO consumers still work through the bridge.

Show me the dry-run command to run first. Do not run the real migration yourself.
